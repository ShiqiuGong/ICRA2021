% This subfunction removes primitives where the number of occurrences of the H1 intermediate fragment is too small.

function [H1_1, H2_1] = RemoveMinorHamp(H1,H2,m)
for r=1:1:size(H1,1)
    
    tempH2 = H2(r,:);
    tempH1 = H1(r,:);
    tempH2(tempH2==0) = [];
    
    % Set screening criteria at here
    tf = find(tempH2 <= m);  % Find indexes with less than m consecutive occurrence frames
    tf = tf(1,2:end-1);      % Remove the first and last elements from this index
    tempH2(tf) = [];         % Deletes the values of H2 and H1 from the position corresponding to this index
    tempH1(tf) = [];
    
    D = size(H1,2)-size(tempH1,2);
    d = size(H2,2)-size(tempH2 ,2);
    
    temp2 = cell(1,D);
    temp3 = zeros(1,d);
    tempH1 = [tempH1, temp2];
    tempH2 = [tempH2, temp3];
    H1_1(r,:) = tempH1;
    H2_1(r,:) = tempH2;
end
for i=1:size(H2_1,2)
    temp = H2_1(:,i);
    if all(temp==0)
        m = i;
        break   
    end
end
H1_1 = H1_1(:,1:m);
H2_1 = H2_1(:,1:m);
end
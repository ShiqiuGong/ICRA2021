% This program is used to train pattern recognition network models ---------
clear
close
clc

load('Train_X.mat');
load('Train_Y.mat');

X = Train_X';
Y = Train_Y';
hiddenSizes = 100;
trainFcn = 'trainscg';
performFcn = 'crossentropy';
net = patternnet(hiddenSizes,trainFcn,performFcn);
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;
net.trainParam.max_fail = 50;
PRnet = train(net,X,Y);
y = PRnet(X);
save('PRnet.mat','PRnet');


%%This function is used to control the robot in V-rep.
function iiwa_Joint_Control
clear all
clc
load('th.mat','th')
%Initialization
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m) 
vrep.simxFinish(-1); % just in case, close all opened connections
clientID=vrep.simxStart('127.0.0.1',19997,true,true,5000,5);
JointHandle=zeros(1,7);
for i=1:7
    [~,JointHandle(i)] = vrep.simxGetObjectHandle(clientID,['LBR_iiwa_14_R820_joint' num2str(i)],vrep.simx_opmode_blocking);
end
vrep.simxSynchronous(clientID,true);
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot);%start

%%
joint_pos1 = th';

k=1;

while k<size(joint_pos1,1)+1
    for i=1:7
        vrep.simxSetJointTargetPosition(clientID,JointHandle(i),joint_pos1(k,i),vrep.simx_opmode_blocking );
    end
    vrep.simxSynchronousTrigger(clientID);
    k=k+1;
end

pause(10)
vrep.simxStopSimulation(clientID,vrep.simx_opmode_oneshot_wait);
vrep.simxFinish(clientID);
vrep.delete(); % call the destructor!
end

% This subfunction again merges adjacent and repeated primitives in H1_1 and recounts the number of repeats.

function [h1,h2] = MergeSameHamp_Again(H1_1,H2_1)
h1 = cell(size(H1_1,1),size(H1_1,2));
for r = 1:1:size(H1_1,1)
    j = 2;
    S = 2;
    s1 = 2;
    for m = 1:1:size(H1_1,2)
        % ����ǰ����
        if m == 1
            h1{r,1} = H1_1{r,1};  % Store new primitives.
            h2(r,1) = 1;          % Store numbers of new primitives.
        end
        
        if m ==2
            h1{r,2} = H1_1{r,2};
            % The count of h2 is left untreated because it is not known whether there is a repetition at the third time
        end
        
        if m >= 3
            if isequal(H1_1{r,m-1},H1_1{r,m}) == 0
                j = j+1;             % If they are not equal, add a new column for h1
                h1{r,j} = H1_1{r,m}; % Putting the newly discovered primitive into h1
                s1 = m;              % Position index when  an inequality are detected
            end
            
            if isequal(s1, S) == 0   % If it's not equal, then it operates. If it's equal, then it does nothing
                J = s1 - S;
                h2(r,j-1) = sum( H2_1(r,S:S+J-1) ); % Record the number of repetitions
                S = s1;                             % Update the previous index
            end
        end
    end
end
h1 = h1(:,1:size(h2,2));
function tem3 = trans(temp)
aaa = temp;
tem=~cellfun(@isempty,aaa);

tem1 = find(tem~=0);
tem2 = aaa(tem1);
tem3 = cell2mat(tem2);
end
function a = atan_2(b,c)
  a = atan2(real(b),real(c));
end
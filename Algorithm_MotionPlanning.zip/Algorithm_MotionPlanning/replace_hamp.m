function h = replace_hamp(h)  
row=size(h,1);col=size(h,2);num=0;
for i=1:1:row
    for j=1:1:col
        if isequal(h{i,j},[])
            h(i,j)={'X'};
            num=num+1;
        end
    end
end

for i=1:1:row
    for j=1:1:col
        temp = h{i,j};
        switch temp
            case 'A'
                h{i,j} = 'a';
            case 'E'
                h{i,j} = 'b';
            case 'P'
                h{i,j} = 'c';
            case 'EP'
                h{i,j} = 'd';
            case 'EO'
                h{i,j} = 'e';
            case 'PO'
                h{i,j} = 'f';
            case 'EPO'
                h{i,j} = 'g';
        end
    end
end

for i=1:1:row
    for j=1:1:col
        if isequal(h{i,j},'X')
            h(i,j)={[]};
            num=num+1;
        end
    end
end

end

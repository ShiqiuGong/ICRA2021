function h = replace_hamp_chain(h)  
row=size(h,1);col=size(h,2);
for i=1:1:row
    for j=1:1:col
        temp = h{i,j};
        switch temp
            case 'adgdgda'
                h{i,j} = 'C0';
            case 'adga'
                h{i,j} = 'C1';
            case 'adgda'
                h{i,j} = 'C2';
            case 'aga'
                h{i,j} = 'C3';
            case 'agfgfga'
                h{i,j} = 'C4';
            case 'agdga'
                h{i,j} = 'C5';
            case 'agfa'
                h{i,j} = 'C6';
            case 'agfga'
                h{i,j} = 'C7';
            case 'adgdga'
                h{i,j} = 'C8';
            case 'agda'
                h{i,j} = 'C9';              
        end
    end
end

end

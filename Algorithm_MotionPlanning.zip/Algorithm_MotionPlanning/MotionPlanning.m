% This function is the main program for motion planning.
% S: Starting position, E: End position, N: Manipulation, R: Arm type
function [T,phi_1,th,HAMPC]= MotionPlanning(S,E,N,R) 
HAMPC1 = 'A-EP-EPO-EP-A';
HAMPC2 = 'A-EPO-A';
HAMPC3 = 'A-EP-EPO-A';
syms x
%% ----- step1: Determine the chain of movement primitives (HAMPC) based on N
switch N
    case 'Level 1 (based on largest probability)'
        HAMPC = HAMPC2;
        
    case 'Level 2 (based on spatial region and largest probability)'
        % E(1):X   E(2):Y
        if E(1)<=0  &&  E(2)>=0   % Region 1
            HAMPC = HAMPC1;
        elseif E(1)>=0               % Region 2,3
            HAMPC = HAMPC2;
        elseif E(1)<=0  && E(2)<=0    % Region 4
            HAMPC = HAMPC3;
        end
        
    case 'Level 3 (based on intelligent pattern recognition network)'
        HAMPC = PatternDecision(S,E);  % Pattern recognition algorithms
end
%% ----- step2: Determine the total time of movement based on S and E.
% fitts law
D = norm([S(1)-E(1), S(2)-E(2), S(3)-E(3)])*1000; % mm 
W = 20;
a=0.3625;
b=0.1325;
T = a + b*log2(2*D/W);

% T = 120*log2(D/W + A) %  Seconds
time_inter = 0.1;
time = 0:time_inter:T;

% Neural Networks
load('BPNN.mat','BPNN');
phi_0 = 0;
P = [S,E];
% Units converted to millimeters and degrees
P = [P(:,1:3)*1000   rad2deg(P(:,4:6))   P(:,7:9)*1000     rad2deg(P(:,10:12))];
phi_1 = BPNN(P');
phi_1 = deg2rad(phi_1);

%% ----- step3: Assigning the duration of each primitive
% Scale the human arm and robotic arm.
% ratio = (420+400+120)/(305+262+100);
% ratio = 1.22;
% 
% S(1)=S(1)*ratio; S(2)=S(2)*ratio; S(3)=S(3)*ratio; 
% E(1)=E(1)*ratio; E(2)=E(2)*ratio; E(3)=E(3)*ratio;

for i=1:1:size(time,2)
    t = time(i);
    if strcmp(HAMPC,'A-EP-EPO-EP-A') == 1
        t1 = 0.0525*T;
        t3 = 0.05*T;
        t2 = T-t1-t3;
        % step4: Quantify each primitive parameter ��E(phi) P O��
        % --- E/phi ---
        dphi = phi_1 - phi_0;
        A = 2*dphi/T;
        k = vpa( int( 0.5*A*(1-cos(2*pi*x/5)), x, 0, t ) ,16);
        phi = double(phi_0 + k);
        % --- P ---
        t1 = t/T;
        xm = S(1) + ( S(1)-E(1) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        ym = S(2) + ( S(2)-E(2) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        zm = S(3) + ( S(3)-E(3) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        % --- O ---
        if t1 <= t && t <= t1+t2
            drx = E(4)-S(4);
            Ax=2*drx/t2;
            kx = vpa( int( 0.5*Ax*(1-cos(2*pi*x/6)), x, 0, t-t1 ) ,16);
            rx = double( E(4)+kx );
            dry = E(5)-S(5);
            Ay=2*dry/t2;
            ky = vpa( int( 0.5*Ay*(1-cos(2*pi*x/6)), x, 0, t-t1 ) ,16);
            ry = double( E(5)+ky );
            drz = E(6)-S(6);
            Az=2*drz/t2;
            kz = vpa( int( 0.5*Az*(1-cos(2*pi*x/6)), x, 0, t-t1 ) ,16);
            rz = double( E(6)+kz );
         else
            rx = E(4); ry = E(5); rz = E(6); 
        end
    elseif strcmp(HAMPC,'A-EPO-A') == 1
        % step4: Quantify each primitive parameter
        % --- E/phi ---
        dphi = phi_1 - phi_0;
        A = 2*dphi/T;
        k = vpa( int( 0.5*A*(1-cos(2*pi*x/5)), x, 0, t ) ,16);
        phi = double(phi_0 + k);
        % --- P ---
        t1 = t/T;
        xm = S(1) + ( S(1)-E(1) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        ym = S(2) + ( S(2)-E(2) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        zm = S(3) + ( S(3)-E(3) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        % --- O ---
        drx = E(4)-S(4);
        Ax=2*drx/T;
        kx = vpa( int( 0.5*Ax*(1-cos(2*pi*x/6)), x, 0, t ) ,16);
        rx = double( E(4)+kx );
        dry = E(5)-S(5);
        Ay=2*dry/T;
        ky = vpa( int( 0.5*Ay*(1-cos(2*pi*x/6)), x, 0, t ) ,16);
        ry = double( E(5)+ky );
        drz = E(6)-S(6);
        Az=2*drz/T;
        kz = vpa( int( 0.5*Az*(1-cos(2*pi*x/6)), x, 0, t ),16 );
        rz = double( E(6)+kz );
    elseif strcmp(HAMPC,'A-EP-EPO-A') == 1
        t1_1 = 0.0575*T;
        t2_1 = T-t1_1;
        % step4: Quantify each primitive parameter
        % --- E/phi ---
        dphi = phi_1 - phi_0;
        A = 2*dphi/T;
        k = vpa( int( 0.5*A*(1-cos(2*pi*x/5)), x, 0, t ) ,16);
        phi = double(phi_0 + k);
        % --- P ---
        t1 = t/T;
        xm = S(1) + ( S(1)-E(1) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        ym = S(2) + ( S(2)-E(2) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        zm = S(3) + ( S(3)-E(3) )*(15*t1^4 - 6*t1^5 - 10*t1^3 );
        % --- O ---
        if t1_1 <= t
            drx = E(4)-S(4);
            Ax=2*drx/t2_1;
            kx = vpa( int( 0.5*Ax*(1-cos(2*pi*x/6)), x, 0, t-t1_1 ) ,16);
            rx = double( E(4)+kx );
            dry = E(5)-S(5);
            Ay=2*dry/t2_1;
            ky = vpa( int( 0.5*Ay*(1-cos(2*pi*x/6)), x, 0, t-t1_1 ),16 );
            ry = double( E(5)+ky );
            drz = E(6)-S(6);
            Az=2*drz/t2_1;
            kz = vpa( int( 0.5*Az*(1-cos(2*pi*x/6)), x, 0, t-t1_1 ),16 );
            rz = double( E(6)+kz );
        else
            rx = E(4); ry = E(5); rz = E(6); 
        end
    end
    
    %% step5��Mapping of primitives to joint angles
    if strcmp(R,'iiwa') == 1
        Lse=0.420;Lew=0.400;Lwm=0;
    end
    %---------
    Rx=[ 1 0 0;0 cos(rx) -sin(rx); 0 sin(rx) cos(rx)];
    Ry=[ cos(ry) 0 sin(ry); 0 1 0; -sin(ry) 0 cos(ry)];
    Rz=[ cos(rz) -sin(rz) 0; sin(rz)  cos(rz) 0;0 0 1];
    Rm=Rz*Ry*Rx;
    %----Wrist Position Solution-----
    A=Rm*[0;0;-Lwm]+[xm;ym;zm];
    Xw=real(A(1));  Yw=real(A(2));  Zw=real(A(3));
    Pw=[Xw,Yw,Zw];    
    %----Elbow Position Solver------
    Lsw=norm([Xw Yw Zw]);
    deta=acos((Lse^2+Lsw^2-Lew^2)/(2*Lse*Lsw));
    Lsh=Lse*cos(deta);
    Leh=Lse*sin(deta);
    beta=atan_2(-Xw,Yw);
    if Yw>=0
        alpha=atan_2(Zw,(Xw^2+Yw^2)^0.5);
    else
        alpha=atan_2(Zw,-(Xw^2+Yw^2)^0.5);
    end
    Xe=-Lsh*sin(beta)*cos(alpha)-Leh*(sin(phi)*cos(beta)+sin(alpha)*sin(beta)*cos(phi));
    Ye=Lsh*cos(beta)*cos(alpha)-Leh*(sin(phi)*sin(beta)-sin(alpha)*cos(beta)*cos(phi));
    Ze=Lsh*sin(alpha)-Leh*cos(alpha)*cos(phi);
    dd=norm([Xe Ye Ze]); cc=norm([Xe-Xw Ye-Yw Ze-Zw]);  bb=norm([Xw-xm Yw-ym Zw-zm]);  arm(i,1:3)=[dd,cc,bb];
    Xe = real(Xe);  Ye = real(Ye);  Ze = real(Ze);
    %-----------------------------------------------------------
    th1(i)=atan_2(Ye,Xe);
    th2(i)=atan_2(Xe/(cos(th1(i)) *Lse),Ze/Lse);
    th4(i)=pi-acos(  (Xw^2+Yw^2+Zw^2-Lse^2-Lew^2)  /  (-2*Lse*Lew) );
    b= (Zw-Lse*cos(th2(i))-Lew*cos(th2(i))*cos(th4(i)))   /   (Lew*sin(th2(i))*sin(th4(i)));
    a= (sin(th1(i))*(Zw*cos(th2(i))-Lse-Lew*cos(th4(i)))+Yw*sin(th2(i)))   /   (-Lew*cos(th1(i))*sin(th2(i))*sin(th4(i)));
    th3(i)=atan_2( real(a) , real(b) );
    a11=Rm(1,1); a12=Rm(1,2); a13=Rm(1,3);
    a21=Rm(2,1); a22=Rm(2,2); a23=Rm(2,3);
    a31=Rm(3,1); a32=Rm(3,2); a33=Rm(3,3);
    ax=a33*cos(th2(i))*sin(th4(i)) + a23*cos(th1(i))*cos(th4(i))*sin(th3(i)) - a33*cos(th3(i))*cos(th4(i))*sin(th2(i)) + a13*cos(th1(i))*sin(th2(i))*sin(th4(i)) - a13*cos(th4(i))*sin(th1(i))*sin(th3(i)) + a23*sin(th1(i))*sin(th2(i))*sin(th4(i)) + a13*cos(th1(i))*cos(th2(i))*cos(th3(i))*cos(th4(i)) + a23*cos(th2(i))*cos(th3(i))*cos(th4(i))*sin(th1(i));
    ay=a23*cos(th1(i))*cos(th3(i)) - a13*cos(th3(i))*sin(th1(i)) + a33*sin(th2(i))*sin(th3(i)) - a13*cos(th1(i))*cos(th2(i))*sin(th3(i)) - a23*cos(th2(i))*sin(th1(i))*sin(th3(i));
    az=a33*cos(th2(i))*cos(th4(i)) + a13*cos(th1(i))*cos(th4(i))*sin(th2(i)) + a23*cos(th4(i))*sin(th1(i))*sin(th2(i)) - a23*cos(th1(i))*sin(th3(i))*sin(th4(i)) + a33*cos(th3(i))*sin(th2(i))*sin(th4(i)) + a13*sin(th1(i))*sin(th3(i))*sin(th4(i)) - a13*cos(th1(i))*cos(th2(i))*cos(th3(i))*sin(th4(i)) - a23*cos(th2(i))*cos(th3(i))*sin(th1(i))*sin(th4(i));
    oz=a32*cos(th2(i))*cos(th4(i)) + a12*cos(th1(i))*cos(th4(i))*sin(th2(i)) + a22*cos(th4(i))*sin(th1(i))*sin(th2(i)) - a22*cos(th1(i))*sin(th3(i))*sin(th4(i)) + a32*cos(th3(i))*sin(th2(i))*sin(th4(i)) + a12*sin(th1(i))*sin(th3(i))*sin(th4(i)) - a12*cos(th1(i))*cos(th2(i))*cos(th3(i))*sin(th4(i)) - a22*cos(th2(i))*cos(th3(i))*sin(th1(i))*sin(th4(i));
    nz=a31*cos(th2(i))*cos(th4(i)) + a11*cos(th1(i))*cos(th4(i))*sin(th2(i)) + a21*cos(th4(i))*sin(th1(i))*sin(th2(i)) - a21*cos(th1(i))*sin(th3(i))*sin(th4(i)) + a31*cos(th3(i))*sin(th2(i))*sin(th4(i)) + a11*sin(th1(i))*sin(th3(i))*sin(th4(i)) - a11*cos(th1(i))*cos(th2(i))*cos(th3(i))*sin(th4(i)) - a21*cos(th2(i))*cos(th3(i))*sin(th1(i))*sin(th4(i));
    % ----------Choose an optimal start for th5 th6 th7.-------------------------------
    if i==1
        th6_1=atan_2((nz^2+oz^2)^0.5,az); %---th6 > 0------
        th5_1=atan_2(ay,ax);
        th7_1=atan_2(oz,-nz);
        sum1=abs(th5_1) +abs(th6_1) +abs(th7_1) ;
        th6_2=atan_2(-(nz^2+oz^2)^0.5,az); %---th6 < 0------
        th5_2=atan_2(-ay,-ax);
        th7_2=atan_2(-oz,nz);
        sum2=abs(th5_2) +abs(th6_2) +abs(th7_2) ;
        if sum1<=sum2 %-----
            th6(1)=th6_1;  th5(1)=th5_1;  th7(1)=th7_1;
        else
            th6(1)=th6_2;  th5(1)=th5_2;  th7(1)=th7_2;
        end
    end
    % ----------------------
    if i>=2
        th6_1=atan_2(real((nz^2+oz^2)^0.5),real(az));
        th6_2=atan_2(real(-(nz^2+oz^2)^0.5),real(az));
        d1=abs(th6_1-th6(i-1));
        d2=abs(th6_2-th6(i-1));
        if d1<d2
            th6(i)=th6_1;
        elseif d1>d2
            th6(i)=th6_2;
        end
        if th6(i)==0
            th6(i)=th6(i)+0.0087;%
        end
        if th6(i)>0
            th5(i)=atan_2(ay,ax);
            th7(i)=atan_2(oz,-nz);
        elseif th6(i)<0
            th5(i)=atan_2(real(-ay),real(-ax));
            th7(i)=atan_2(real(-oz),nz);
        end
    end
end
th(1,:) = th1;  th(2,:) = th2;  th(3,:) = th3;  th(4,:) = th4;  th(5,:) = th5;  th(6,:) = th6;  th(7,:) = th7;save
save('th.mat','th');
end


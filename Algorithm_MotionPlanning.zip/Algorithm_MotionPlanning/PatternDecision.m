function HAMPC = PatternDecision(S,E)
load('PRNet.mat','PRnet');

P = [S,E];
% Units converted to millimeters
P = [P(:,1:3)*1000   rad2deg(P(:,4:6))   P(:,7:9)*1000     rad2deg(P(:,10:12))];
n = PRnet(P');
n = round(n);
if n == [1 0 0]'
    HAMPC = 'A-EP-EPO-A';
elseif n == [0 1 0]'
    HAMPC = 'A-EP-EPO-EP-A';
elseif n == [0 0 1]'
    HAMPC = 'A-EPO-A';
end
%  This is the main function for Extracting human arm action primitive chains

close all;  
clearvars;  
clc;

% Loading a bvh file
file_address = [pwd '\BVH'];      % Retrieve current folder address
file = dir([file_address '\*.bvh']);

% Extracting the primitive for each frame of motion from the bvh file
HAMP = ExtractHamp(file,file_address);

disp('Note: The primitive chains of all samples were extracted --')
disp('--')

% Merge adjacent and identical primitives in a chain of primitives
[H1,H2] = MergeSameHamp(HAMP);
disp('Note: The merging of adjacent and identical primitives in each sample was completed --')
disp('--')

% Remove primitives with very few occurrences in the intermediate fragments of H1 , m=2 represents the filter criterion (number of consecutive frames)
[H1_1, H2_1] = RemoveMinorHamp(H1,H2,2);
disp('Note: Primitives with very few occurrences in the intermediate fragments were removeed --')
disp('--')

% Merge the adjacent and duplicate primitives in H1_1 again, and recount the number of duplicates
[h1,h2] = MergeSameHamp_Again(H1_1,H2_1);

disp('Note: Re-merger completed --')
disp('--')
disp('Note: The available primitive chains are placed in the matrix h1 --')
disp('Note: The corresponding number of primitives is placed in the matrix h2 --')




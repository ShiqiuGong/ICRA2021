% This subfunction merges adjacent primitives with the same category in the primitive chains.
% The primitive chain are returned in H1 and the numbers of corresponding HAMPs are returned in H2.

function [H1,H2] = MergeSameHamp(HAMP)
HAMP{1, size(HAMP,2)+1} = []; % The purpose of adding another column after HAMP is to deal with the problem that H2 does not compute the last column.
H1 = cell(size(HAMP,1),size(HAMP,2));
for r = 1:1:size(HAMP,1)
    j = 2;
    S = 2;
    s1 = 2;
    for s = 1:1:size(HAMP,2)
        % Processing the first frame of data
        if s == 1
            H1{r,1} = HAMP{r,1};
            H2(r,1) = 1;
        end
        
        if s == 2
            H1{r,2} = HAMP{r,2};
            % H2 counts are not increased yet, as the number of repetitions is not known at this time
        end
        
        if s >= 3
            if isequal(HAMP{r,s-1},HAMP{r,s}) == 0
                j = j+1;               % If they are not equal, add a new column to H1
                H1{r,j} = HAMP{r,s};   % Putting the newly discovered primitive into H1
                s1 = s;                % Position index when the record detects an inequality
            end
            % After each search, update some data and count the number of repetitions. 
            % s1:location index when different primitives are found   S��index of the last recorded different primitive
            if isequal(s1, S) == 0   % If it's not equal, then it operates. If it's equal, then it does nothing
                J = s1 - S;          % The number of repeats is equal to the current index minus the previous index
                H2(r,j-1) = J;       % Record the number of repetitions
                S = s1;              % Update the previous index
            end
        end
    end
end
H1 = H1(:,1:size(H2,2));
end
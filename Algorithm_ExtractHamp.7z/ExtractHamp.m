% This subfunction extracts the human arm movement primitives from the BVH file.

function HAMP = ExtractHamp(file,file_address)
    N = 0;
for n=1:1:length(file)
% for n = 1:1:10       % Test the program with a small number of samples
    clearvars -except file file_address ActionName n N HAMP;
    file_add = [file_address '\'];
    filename = [file_add,file(n).name];
    fileID = fopen(filename,'r');
    info = textscan(fileID,'%s');  fclose(fileID);
    
    % Extract the motion data of the right arm from the BVH file.
    OFFSET = [str2num(info{1}{6}),str2num(info{1}{7}),str2num(info{1}{8}); % The offset of hips relative to origin
        str2num(info{1}{115}),str2num(info{1}{116}),str2num(info{1}{117}); % The offset of spine relative to hips
        str2num(info{1}{127}),str2num(info{1}{128}),str2num(info{1}{129}); % The offset of spine1 relative to spine
        str2num(info{1}{139}),str2num(info{1}{140}),str2num(info{1}{141}); % The offset of spine2 relative to spine1
        str2num(info{1}{198}),str2num(info{1}{199}),str2num(info{1}{200}); % The offset of RightShoulder relative to spine2
        str2num(info{1}{210}),str2num(info{1}{211}),str2num(info{1}{212}); % The offset of RightArm relative to RightShoulder
        str2num(info{1}{222}),str2num(info{1}{223}),str2num(info{1}{224}); % The offset of RightForeArm relative to RightArm
        str2num(info{1}{234}),str2num(info{1}{235}),str2num(info{1}{236}); % The offset of RightHand relative to RightForeArm
        -18,0,0];   % The offset of endpoint relative to the wrist, set as 18 cm
    frames = str2num(info{1}{878}); % Total number of frames
    ang = cell(frames,180);
    
    %  Read the angles of the bones
    for e = 1:1:frames
        for j = 1:1:180
            ang = info{1}(881+181*(e-1)+j);% Put the data on one line for each frame
            A(e,j) = str2num(ang{1});
            if abs(A(e,j)) < 0.0001
                A(e,j) = 0;
            end
        end
    end
    
    % Calculate the T Matrix between two adjacent bones
    i = 1;    m = 1; % m is the sampling interval
    for k = 1:m:frames
        T5_6{i,1} = T_matrix(A(k,3+14*3+1),A(k,3+14*3+2),A(k,3+14*3+3),OFFSET(6,1:3)); % rightarm relative to shoulder��Shoulder is the base frame��
        T6_7{i,1} = T_matrix(A(k,3+15*3+1),A(k,3+15*3+2),A(k,3+15*3+3),OFFSET(7,1:3)); % rightforearm relative to rightarm
        T7_8{i,1 }= T_matrix(A(k,3+16*3+1),A(k,3+16*3+2),A(k,3+16*3+3),OFFSET(8,1:3)); % righthand relative to rightforearm
        T8_9{i,1} = T_matrix(A(k,3+24*3+1),A(k,3+24*3+2),A(k,3+24*3+3),OFFSET(9,1:3)); % middle relative to righthand
        T9_10{i,1} = T_matrix(A(k,3+25*3+1),A(k,3+25*3+2),A(k,3+25*3+3),[0 0 0]);      % middle_1(endpoint) relative to middle
        
        % T Matrix of each node relative to the shoulder
        T5_10{i,1} = T5_6{i,1}*T6_7{i,1}*T7_8{i,1}*T8_9{i,1}*T9_10{i,1}; % endpoint relative to shoulder
        T5_8{i,1} = T5_6{i,1}*T6_7{i,1}*T7_8{i,1};                       % hand relative to shoulder
        T5_7{i,1} = T5_6{i,1}*T6_7{i,1};                                 % forearm relative to shoulder
        T5_6{i,1} = T5_6{i,1};                                           % arm relative to shoulder
        
        % Positions, relative to the shoulder
        PS{i,1} = T5_6{i}(1:3,4);  % rightarm relative to shoulder
        PE{i,1} = T5_7{i}(1:3,4);  % forearm relative to shoulder
        PW{i,1} = T5_8{i}(1:3,4);  % hand relative to shoulder
        PM{i,1} = T5_10{i}(1:3,4); % endpoint relative to shoulder
        
        % Express the positions of all nodes in the shoulder coordinate system
        Ps{i,1} = PS{i,1}-PS{i,1}; % The shoulder position is set to [0 0 0].
        Pe{i,1} = PE{i,1}-PS{i,1};
        Pw{i,1} = PW{i,1}-PS{i,1};
        Pm{i,1} = PM{i,1}-PS{i,1};
        
        % Positions of endpoint, in X, Y and Z directions, and in  the shoulder coordinate system
        X(i) = Pm{i}(1);
        Y(i) = Pm{i}(2);
        Z(i) = Pm{i}(3);
        
        % Orientations of endpoint, in X, Y and Z directions, and in  the shoulder coordinate system
        R{i,1} = [ T5_10{i,1}(1,1) T5_10{i,1}(1,2) T5_10{i,1}(1,3);
            T5_10{i,1}(2,1) T5_10{i,1}(2,2) T5_10{i,1}(2,3);
            T5_10{i,1}(3,1) T5_10{i,1}(3,2) T5_10{i,1}(3,3)];
        rx(1) = atan2(-R{1,1}(2,3),(R{1,1}(2,1)*R{1,1}(2,1)+R{1,1}(2,2)*R{1,1}(2,2))^0.5);
        if i >=2
            rx1(i-1) = atan2(-R{i,1}(2,3),(R{i,1}(2,1)*R{i,1}(2,1)+R{i,1}(2,2)*R{i,1}(2,2))^0.5);
            rx2(i-1) = atan2(-R{i,1}(2,3),-(R{i,1}(2,1)*R{i,1}(2,1)+R{i,1}(2,2)*R{i,1}(2,2))^0.5);
            drx1 = rad2deg(abs(rx1(i-1)-rx(i-1)));
            drx2 = rad2deg(abs(rx2(i-1)-rx(i-1)));
            if drx1 < drx2
                rx(i) = rx1(i-1);
            else
                rx(i) = rx2(i-1);
            end
            cha_rx = rx(i)-rx(i-1);
            if pi < cha_rx
                rx(i) = rx(i)-2*pi;
            elseif cha_rx < -pi
                rx(i) = rx(i)+2*pi;
            end
        end
        ry(i) = atan2(R{i,1}(1,3)/cos(rx(i)),R{i,1}(3,3)/cos(rx(i)));
        if i >= 2
            cha_ry = ry(i)-ry(i-1);
            if pi < cha_ry
                ry(i) = ry(i)-2*pi;
            elseif cha_ry < -pi
                ry(i) = ry(i)+2*pi;
            end
        end
        rz(i) = atan2(R{i,1}(2,1)/cos(rx(i)),R{i,1}(2,2)/cos(rx(i)));
        if i >= 2
            cha_rz = rz(i)-rz(i-1);
            if pi < cha_rz
                rz(i) = rz(i)-2*pi;
            elseif cha_rz < -pi
                rz(i) = rz(i)+2*pi;
            end
        end
        x(i,:) = [Ps{i}(1) Pe{i}(1) Pw{i}(1) Pm{i}(1)];
        y(i,:) = [Ps{i}(2) Pe{i}(2) Pw{i}(2) Pm{i}(2)];
        z(i,:) = [Ps{i}(3) Pe{i}(3) Pw{i}(3) Pm{i}(3)];
        
        % Solve for the swivel angle phi at each moment
        P1v1{i,1} = [x(i,2)-x(i,1) y(i,2)-y(i,1) z(i,2)-z(i,1)]; % Vector formed by the shoulder and elbow
        P1v2{i,1} = [x(i,3)-x(i,2) y(i,3)-y(i,2) z(i,3)-z(i,2)]; % Vector formed by the elbow and wrist
        P1f{i,1} = cross(P1v1{i,1},P1v2{i,1});
        P2v1{i,1} = [0 -1 0];                                    % vertical unit vector
        P2v2{i,1} = [x(i,3)-x(i,1) y(i,3)-y(i,1) z(i,3)-z(i,1)]; % Vector formed by the shoulder and wrist
        P2f{i,1} = cross(P2v1{i,1},P2v2{i,1});
        phi(i) = acos( dot(P1f{i,1},P2f{i,1}) / (norm(P1f{i,1})*norm(P2f{i,1})) );
        i = i + 1;
    end
    
    % ************************** data processing *************************************** %
    
    %   X=10*smooth(X',0.1,'moving');   Y=10*smooth(Y',0.1,'moving');   Z=10*smooth(Z',0.1,'moving');  % smooth the motion data
    X = 10*X';   Y = 10*Y';   Z = 10*Z';  % Convert centimetre to millimetres
    
    % Extracts the available motion fragments
    dx = diff(X);dy = diff(Y);dz = diff(Z);
    for i = 1:size(dx,1)
        vel(1,i) = norm([dx(i),dy(i),dz(i)]);
    end
    for i = 1:size(vel,2) 
        if abs(vel(1,i)) <= 0.02*max(vel) % Excluding the data, less than 1%
            vel(1,i) = 0;
        end
    end
    [~,col] = find(vel==max(vel));        % index of maximum
    before_vel = vel(1,1:col);
    later_vel = vel(1,col:size(vel,2));   % The movement is divided into two parts
    [~,b1] = find(before_vel==0);         % Index forward to find the first zero value
    [~,b2] = find(later_vel==0);
    b2 = b2+col-1;                        % Index back to find the first zero value
    non0_vel = vel(1,max(b1):min(b2));    % Dealing with multiple 0 values
    start_p = max(b1);
    end_p = max(b1)+size(non0_vel,2);     % Index of the start and end points of valid data
    
    % output the available motion fragments
    X = X(start_p - 2:end_p + 1,1);
    Y = Y(start_p - 2:end_p + 1,1);
    Z = Z(start_p - 2:end_p + 1,1); 
    rx = rx(1,start_p - 2:end_p + 1);
    ry = ry(1,start_p - 2:end_p + 1);
    rz = rz(1,start_p - 2:end_p + 1);
    rx = rad2deg(rx);
    ry = rad2deg(ry);
    rz = rad2deg(rz);
    phi = phi(1,start_p - 2:end_p + 1);
    phi = rad2deg(phi);
    
    % computing speeds
    dx = [0;diff(X);0];     dy = [0;diff(Y);0];     dz = [0;diff(Z);0];
    drx = [0,diff(rx),0];   dry = [0,diff(ry),0];   drz = [0,diff(rz),0];
    dphi = [0,diff(phi),0];
    for j = 1:1:size(dx,1)
        dp(j) = norm([dx(j) dy(j) dz(j)]);
        dr(j)  =norm([drx(j) dry(j) drz(j)]);
    end
    
    % eliminate microscopic fluctuations
    for jj = 1:1:size(dp,2)
        if abs(dp(jj)*10) <= 0.01*max(dp)  % millimeter
            dp(jj) = 0;
        end
        if abs(dr(jj)) <= 0.01*max(dr)     % degree
            dr(jj) = 0;
        end
        if abs(dphi(jj)) <= 0.01*max(dphi) % degree
            dphi(jj) = 0;
        end
    end
    
    % ************************** HAMP extracting *************************************** %
    % the extracted HAMPs are stored in cell Matrix HAMP
    
    E_MP = cell(size(drx,2),3);  % Put three HAMP elements in three columns
    for t = 1:1:size(drx,2)
        if dphi(t) ~= 0
            E_MP{t,1} = 'E';
            g1(t) = 1;
        else
            E_MP{t,1} = '';
            g1(t) = 0;
        end
        
        if dp(t) ~= 0
            E_MP{t,2} = 'P';
            g2(t) = 1;
        else
            E_MP{t,2}=''; 
            g2(t)=0;
        end
        
        if dr(t) ~= 0
            E_MP{t,3} = 'O';
            g3(t) = 1;
        else
            E_MP{t,3} = '';
            g3(t) = 0;
        end
        
        if g1(t)==0 &&  g2(t)==0 && g3(t)==0
            HAMP{n,t} = 'A';
        else
            HAMP{n,t} = [E_MP{t,1},E_MP{t,2},E_MP{t,3}];
        end
    end
    N = N +1;
    disp([num2str(N) ' bvh files have been processed'])
end
end
